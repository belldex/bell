BELL public verifier

Install Node.js 24, then run npm install and npm run verify:bell in this directory.
Set RH_MAINNET_RPC_SECONDARY or RH_MAINNET_ARCHIVE_RPC if your RPC restricts historical log ranges.
INCOMPLETE means evidence is still pending; --require-complete returns a failing exit code for pending evidence.
No private keys are needed. This program only reads chain data.
