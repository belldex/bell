# v4 hook starter

A v4 hook for v4 Marketplace: src/MyHook.sol implements ILog, the interface the hook stack calls.

    forge install foundry-rs/forge-std uniswap/v4-core
    RH_RPC_URL=https://rpc.mainnet.chain.robinhood.com forge test

Then open the Build a v4 hook page, drop src/MyHook.sol in, and the site compiles it with
solc 0.8.26, deploys it from your wallet, verifies it on Sourcify and lists it.

Limits: beforeSwap runs with the gas limit you list (10,000 to 80,000), afterSwap gets 40,000
more if you turn it on, answers are capped at 96 bytes, royalty is 0 to 10 bps, and three failed
runs in seven days burn 10% of the 10,000 $V4M stake.
