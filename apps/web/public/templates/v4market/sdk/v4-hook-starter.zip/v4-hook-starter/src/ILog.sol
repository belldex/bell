// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {PoolKey} from "v4-core/types/PoolKey.sol";
import {SwapParams} from "v4-core/types/PoolOperation.sol";
import {BalanceDelta} from "v4-core/types/BalanceDelta.sol";

/// @notice The interface every v4 hook listed on v4 Marketplace implements. The hook stack (the
/// contract named Dam on chain) calls it with a hard gas stipend inside a guarded call: a hook that
/// reverts, runs out of gas or returns malformed data is skipped and recorded as a failed run.
/// Listed hooks never hold pool funds (hooks that hold funds come later, with a larger stake).
interface ILog {
    /// @notice Called once when a pool stacks the hook, with the pool-specific config the pool owner chose.
    function onStack(PoolKey calldata key, bytes calldata cfg) external;

    /// @notice Fee proposal in pips (1_000_000 = 100%), 0 meaning no opinion. `rebatePct` (0 to 100)
    /// lowers the composed fee; the largest rebate in the stack applies. `veto` refuses the swap.
    function beforeSwap(address origin, PoolKey calldata key, SwapParams calldata params)
        external
        returns (uint24 feePips, uint8 rebatePct, bool veto);

    /// @notice Optional bookkeeping after the swap. Only called when the hook was listed with afterSwap on.
    function afterSwap(PoolKey calldata key, SwapParams calldata params, BalanceDelta delta) external;
}
