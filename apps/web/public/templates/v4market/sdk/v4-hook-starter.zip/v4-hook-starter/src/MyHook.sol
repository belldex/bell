// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

// A v4 hook template for v4 Marketplace. It compiles next to ILog.sol (served at /sdk/ILog.sol)
// and Uniswap v4-core. The Build a v4 hook page compiles, deploys and lists it for you.
//
// Rules the hook stack enforces on every swap:
//   - only the hook stack calls you (its address is passed to the constructor);
//   - you run with the gas limit you listed: 10,000 to 80,000 for beforeSwap,
//     plus a 40,000 stipend for afterSwap if you list the hook with afterSwap on;
//   - your answer is at most 96 bytes; a revert, an out-of-gas or a malformed answer is a
//     failed run, and three failed runs in seven days burn 10% of your stake;
//   - your royalty is 0 to 10 bps of the swap output, set when you list the hook;
//   - the composed fee is the highest proposal in the stack, lowered by the largest rebate.

import {ILog} from "./ILog.sol";
import {PoolKey} from "v4-core/types/PoolKey.sol";
import {PoolId, PoolIdLibrary} from "v4-core/types/PoolId.sol";
import {SwapParams} from "v4-core/types/PoolOperation.sol";
import {BalanceDelta} from "v4-core/types/BalanceDelta.sol";

contract MyHook is ILog {
    using PoolIdLibrary for PoolKey;

    /// The hook stack contract (named Dam on chain) that is allowed to call this hook.
    address public immutable hookStack;

    /// Fee this hook proposes in each pool, in pips (3000 = 0.30%).
    mapping(PoolId => uint24) public feeOf;

    error NotHookStack();

    constructor(address hookStack_) {
        hookStack = hookStack_;
    }

    modifier onlyHookStack() {
        if (msg.sender != hookStack) revert NotHookStack();
        _;
    }

    /// Called once when a pool stacks this hook. `cfg` is chosen by the pool owner:
    /// here, an optional flat fee in pips, 3000 when empty.
    function onStack(PoolKey calldata key, bytes calldata cfg) external onlyHookStack {
        feeOf[key.toId()] = cfg.length == 0 ? 3000 : abi.decode(cfg, (uint24));
    }

    /// Called before every swap in a pool that stacks this hook.
    /// Return (fee proposal in pips or 0 for no opinion, rebate percent 0 to 100, veto).
    function beforeSwap(address, PoolKey calldata key, SwapParams calldata)
        external
        view
        onlyHookStack
        returns (uint24, uint8, bool)
    {
        return (feeOf[key.toId()], 0, false);
    }

    /// Called after the swap only if the hook was listed with afterSwap on.
    function afterSwap(PoolKey calldata, SwapParams calldata, BalanceDelta) external onlyHookStack {}
}
