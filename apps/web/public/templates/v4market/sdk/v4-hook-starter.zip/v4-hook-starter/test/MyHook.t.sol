// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

// Foundry fork test for the v4 hook template.
//   forge install foundry-rs/forge-std uniswap/v4-core
//   remappings: v4-core/=lib/v4-core/src/  forge-std/=lib/forge-std/src/
//   RH_RPC_URL=https://rpc.mainnet.chain.robinhood.com forge test

import {Test} from "forge-std/Test.sol";
import {MyHook} from "../src/MyHook.sol";
import {PoolKey} from "v4-core/types/PoolKey.sol";
import {Currency} from "v4-core/types/Currency.sol";
import {IHooks} from "v4-core/interfaces/IHooks.sol";
import {SwapParams} from "v4-core/types/PoolOperation.sol";

contract MyHookTest is Test {
    // The hook stack on Robinhood Chain (contract named Dam).
    address constant HOOK_STACK = 0xfa80B85CD044Be80795e3344bE1A7435Dbb3fAcc;
    address constant USDG = 0x5fc5360D0400a0Fd4f2af552ADD042D716F1d168;
    address constant TSLA = 0x322f0929c4625ed5bad873c95208D54e1c003B2D;

    MyHook hook;
    PoolKey key;

    function setUp() public {
        vm.createSelectFork(vm.envString("RH_RPC_URL"));
        hook = new MyHook(HOOK_STACK);
        (address c0, address c1) = TSLA < USDG ? (TSLA, USDG) : (USDG, TSLA);
        key = PoolKey(Currency.wrap(c0), Currency.wrap(c1), 0x800000, 60, IHooks(HOOK_STACK));
    }

    function test_proposesConfiguredFee() public {
        vm.prank(HOOK_STACK);
        hook.onStack(key, abi.encode(uint24(5000)));
        vm.prank(HOOK_STACK);
        uint256 g = gasleft();
        (uint24 fee, uint8 rebate, bool veto) = hook.beforeSwap(address(this), key, SwapParams(true, -1e18, 0));
        assertLt(g - gasleft(), 80_000, "beforeSwap must fit its listed gas limit");
        assertEq(fee, 5000);
        assertEq(rebate, 0);
        assertFalse(veto);
    }

    function test_onlyHookStack() public {
        vm.expectRevert(MyHook.NotHookStack.selector);
        hook.onStack(key, "");
    }
}
